export class Category {
    'categoryId': number;
    'categoryName': string;

    constructor(id:number, name:string) {
        this.categoryId = id;
        this.categoryName = name;
    }
}
