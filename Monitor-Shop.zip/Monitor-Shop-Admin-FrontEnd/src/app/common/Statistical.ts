export class Statistical {
    'month': number;
    'date': Date;
    'amount': number;
    'count': number;
}
