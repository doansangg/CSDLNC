package com.mshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonitorShopApplicationTests {

	@Test
	void contextLoads() {
	}

}
